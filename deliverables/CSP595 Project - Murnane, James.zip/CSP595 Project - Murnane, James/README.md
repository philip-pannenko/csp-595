CSP-595 Build Instructions
==========================


Project Run Instruction:
------------------------
The directory 'csp-595' should be copied into 
the apache-tomcat/webapps folder of the reviewer.  
Source files are also contained within this directory.

url: http://localhost/csp-595/




Generated using LOCMetrics.exe
------------------------------
Overall
Symbol			Count		Definition
Source Files		64		Source Files
Directories		19		Directories
LOC			4283		Lines of Code
BLOC			802		Blank Lines of Code
SLOC-P			3407		Physical Executable Lines of Code
SLOC-L			2030		Logical Executable Lines of Code
MVG			329		McCabe VG Complexity
C&SLOC			1		Code and Comment Lines of Code
CLOC			74		Comment Only Lines of Code
CWORD			455		Commentary Words
HCLOC			3		Header Comment Lines of Code
HCWORD			28		Header Commentary Words

